package l4_19;
import java.util.Scanner;
public class detail extends plant {
    private String name;
    Scanner scan=new Scanner(System.in);
    
    @Override
    public void Create(){
        System.out.println("�������� ������");
        name=scan.nextLine();
    }
    
    @Override
    public void Info(){
        System.out.println(name);
    }
}
