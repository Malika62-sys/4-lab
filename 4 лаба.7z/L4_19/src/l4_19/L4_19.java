package l4_19;

public class L4_19 {
public static void main(String[] args) {
work w = new work();
w.start();
}
}
