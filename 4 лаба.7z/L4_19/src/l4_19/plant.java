package l4_19;
public abstract class plant{
       
    public void Create()
    {
        
    }
    
    public void Info()
    {
        
    }
    
}
