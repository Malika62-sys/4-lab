package l4_19;
import java.util.Scanner;
public class workshop extends plant{
    public String[] mArr = new String[35];
    private String name;
    Scanner scan=new Scanner(System.in);

    @Override
    public void Create(){
        System.out.println("������� ����� ����");
        name=scan.nextLine();
    }
    
    @Override
    public void Info(){
        System.out.println("��� ����� - " + name);
        if (mArr!=null)
        {
            System.out.println("� ��� ����:");
            for(int i =0;i<mArr.length;i++)
            {
                if (mArr[i]!=null)
                {
                    System.out.println(mArr[i]);
                }
            }
        }
    }
}
